# Setup

#pylab inline
from pylab import *

from helper_functions import *
from doublet_detector import *
from collections import defaultdict

plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = 'Arial'
plt.rc('font', size=14)
plt.rcParams['pdf.fonttype'] = 42

#Load data

sample_name = ['P9A', 'P11A', 'P11B', 'P12A']

min_tot = [1000 for s in sample_name] # initial guess for total transcript counts threshold
nSamp = len(sample_name)
input_path = 'raw_counts/'

# D stores all the data; one entry per library
D = {}

for j,s in enumerate(sample_name):
    D[s] = {}
    D[s]['meta'] = {'min_tot': min_tot[j]}

# load counts matrices -- try to load from npz file (fast), 
# otherwise load from text file (slow) and build npz file for next time

for s in sample_name:
    print ('_________________', s)
    
    if os.path.isfile(input_path + s + '.raw_counts.unfiltered.npz'):
        print ('Loading from npz file')
        D[s]['E'] = scipy.sparse.load_npz(input_path + s + '.raw_counts.unfiltered.npz')
    else:
        print ('Loading from text file')
        D[s]['E'] = text_to_sparse(input_path + s + '.counts.tsv.gz', 
                                   delim = '\t', start_row = 1, start_column = 1, 
                                   get_gene_names = False, get_barcodes = False)
        scipy.sparse.save_npz(input_path + s + '.raw_counts.unfiltered.npz', D[s]['E'], compressed = True)
    print (D[s]['E'].shape)

gene_list = np.array(load_genes(input_path + 'genes.txt'))

# Filter cells by total counts

# plot total counts histograms - don't actually filter out any barcodes yet


# adjust total counts thresholds
D['P9A']['meta']['min_tot'] = 900
D['P11A']['meta']['min_tot'] = 700
D['P11B']['meta']['min_tot'] = 800
D['P12A']['meta']['min_tot'] = 800

for s in sample_name:
    D[s]['total_counts'] = np.sum(D[s]['E'], axis=1).A[:,0]

    fig = plt.figure()
    ax = fig.add_subplot(111)
    ax.hist(D[s]['total_counts'], bins=np.logspace(0, 6, 50))
    ax.set_xscale('log')
    ax.set_xlabel('Transcripts per barcode')
    ax.set_ylabel('Number of barcodes')

    
    ax.plot([D[s]['meta']['min_tot'],D[s]['meta']['min_tot']],ax.get_ylim());
    title(s)


    ix = D[s]['total_counts'] >= D[s]['meta']['min_tot']
    print (s, np.sum(ix), '/', D[s]['E'].shape[0], np.median(D[s]['total_counts'][ix]), np.mean(D[s]['total_counts'][ix]))

# Actually filter out low-count barcodes

for s in sample_name:
    print ('---  %s ---' %s)
    print ('Pre-filter: %i barcodes' %D[s]['E'].shape[0])
    D[s]['cell_index'] = np.arange(D[s]['E'].shape[0])
    tmpfilt = np.nonzero(D[s]['total_counts'] >= D[s]['meta']['min_tot'])[0]
    D[s] = filter_dict(D[s], tmpfilt)
    print ('Post-filter: %i barcodes' %D[s]['E'].shape[0])
    
del tmpfilt

# Filter cells by mito fraction

# get mitochondrial genes

mt_ix = [i for i,g in enumerate(gene_list) if g.startswith('mt-')]
print ([gene_list[i] for i in mt_ix])

# plot mito-gene frac histograms - don't actually filter out any cells yet

# set mito-gene frac threshold
for s in sample_name:
    D[s]['meta']['max_mt'] = 0.15

for s in sample_name:
    fig = plt.figure(figsize=(8, 6))
    ax = fig.add_subplot(111, xscale='linear', yscale='linear',
        xlabel='MT frac.', ylabel='no. cells')

    D[s]['mito_frac'] = np.sum(D[s]['E'][:,mt_ix], axis=1).A[:,0] / np.sum(D[s]['E'], axis=1,dtype=float).A[:,0]

    ax.hist(D[s]['mito_frac'], cumulative=False, 
            bins=np.linspace(0, 1, 40))

    ax.plot([D[s]['meta']['max_mt'],D[s]['meta']['max_mt']],ax.get_ylim());
    title(s)

    print (D[s]['E'].shape[0], np.sum(D[s]['mito_frac'] <= D[s]['meta']['max_mt']))

# Actually filter out mito-high cells

for s in sample_name:
    print ('---  %s ---' %s)
    print ('Pre-filter: %i barcodes' %D[s]['E'].shape[0])
    tmpfilt = np.nonzero(D[s]['mito_frac'] <= D[s]['meta']['max_mt'])[0]
    D[s] = filter_dict(D[s], tmpfilt)
    print ('Post-filter: %i barcodes' %D[s]['E'].shape[0])
    
del tmpfilt

# Merge data, normalize

# create master dataset (all SPRING subsets will refer back to this)

samp_lookup = {}
samp_id_flat = np.array([],dtype=str)
for s in D.keys():
    samp_id_flat = np.append(samp_id_flat, [s] * D[s]['E'].shape[0])
    
E = scipy.sparse.lil_matrix((len(samp_id_flat), len(gene_list)), dtype=int)
total_counts = np.zeros(len(samp_id_flat), dtype=int)
mito_frac = np.zeros(len(samp_id_flat), dtype=float)

for s in D.keys():
    print (s)
    E[samp_id_flat == s, :] = D[s]['E']
    total_counts[samp_id_flat == s] = D[s]['total_counts']
    mito_frac[samp_id_flat == s] = D[s]['mito_frac']

E = E.tocsc()

# remove genes that are not expressed by any cells

keep_genes = (E.sum(0) > 0).A.squeeze()
print (sum(keep_genes), '/', len(keep_genes))

E = E[:,keep_genes]
gene_list = gene_list[keep_genes]

# normalize by total counts

E = tot_counts_norm_sparse(E)[0]

# Save base directory files

# Set path for saving data -- you'll have to change this for your own setup.
# This path should be a subdirectory of your local copy of SPRING,
# specifically, {path_to_SPRING}/data/client_datasets/{main_dataset_name}. 
# See example below, where springViewer_1_6_dev.html is located in ../

main_spring_dir = '../data/client_datasets/example/'

if not os.path.exists(main_spring_dir):
    os.makedirs(main_spring_dir)

np.savetxt(main_spring_dir + 'genes.txt', gene_list, fmt='%s')


# save master expression matrix in hdf5 format

import h5py

print ('Saving hdf5 file for fast gene loading...')
E = E.tocsc()
hf = h5py.File(main_spring_dir + 'counts_norm_sparse_genes.hdf5', 'w')
counts_group = hf.create_group('counts')
cix_group = hf.create_group('cell_ix')

hf.attrs['ncells'] = E.shape[0]
hf.attrs['ngenes'] = E.shape[1]

for iG, g in enumerate(gene_list):
    if iG % 3000 == 0:
        print (iG, '/', len(gene_list))
    counts = E[:,iG].A.squeeze()
    cell_ix = np.nonzero(counts)[0]
    counts = counts[cell_ix]
    
    counts_group.create_dataset(g, data = counts)
    cix_group.create_dataset(g, data = cell_ix)

hf.close()

##############

print ('Saving hdf5 file for fast cell loading...')
E = E.tocsr()
hf = h5py.File(main_spring_dir + 'counts_norm_sparse_cells.hdf5', 'w')
counts_group = hf.create_group('counts')
gix_group = hf.create_group('gene_ix')

hf.attrs['ncells'] = E.shape[0]
hf.attrs['ngenes'] = E.shape[1]

for iC in range(E.shape[0]):
    if iC % 3000 == 0:
        print (iC, '/', E.shape[0])
    counts = E[iC,:].A.squeeze()
    gene_ix = np.nonzero(counts)[0]
    counts = counts[gene_ix]
    
    counts_group.create_dataset(str(iC), data = counts)
    gix_group.create_dataset(str(iC), data = gene_ix)

hf.close()


# It turns out scipy sparse npz format is faster in some cases. Save this too.

E = E.tocsc()
scipy.sparse.save_npz(main_spring_dir + '/counts_norm.npz', E, compressed = False)

    
# Save SPRING files
# Save individual samples¶

g2m_genes = ['Ube2c','Hmgb2','Hmgn2','Tuba1b','Mki67','Ccnb1','Tubb','Top2a','Tubb4b']


# For faster knn graph building, install a library called annoy: "pip install annoy"
# This is especially noticeable if running the doublet detector (i.e. when run_woublet=True)

E = E.tocsc()

for s in sample_name:
    t0 = time.time()
    print ('________________', s)
    
    cell_ix = samp_id_flat == s
    
    out = run_all_spring_1_6(E[cell_ix,:],
                     list(gene_list), s, main_spring_dir, normalize=False, tot_counts_final = total_counts[cell_ix],
                     min_counts = 3, min_cells = 3, min_vscore_pctl = 85, 
                     show_vscore_plot = True, num_pc = 25, pca_method = '', k_neigh=4, use_approxnn = False,
                     output_spring = True, num_force_iter = 200, 
                     #exclude_corr_genes_list=[g2m_genes], exclude_corr_genes_minCorr=0.2
                     )
    
    np.save(main_spring_dir + s + '/cell_filter.npy', np.nonzero(cell_ix)[0])
    np.savetxt(main_spring_dir + s + '/cell_filter.txt', np.nonzero(cell_ix)[0], fmt='%i')
    
    print (time.time() - t0)


# Save merged samples¶

# set up various merged samples

merge_setup = {'allMerged': sample_name,
               'P11Merged': ['P11A', 'P11B']
               }

# save data including cell cycle-correlated genes

for s, smerge in merge_setup.items():
    t0 = time.time()
    print ('________________', s)
    
    cell_ix = np.in1d(samp_id_flat, smerge)
    
    run_all_spring_1_6(E[cell_ix,:],
                     list(gene_list), s, main_spring_dir, normalize=False, tot_counts_final = total_counts[cell_ix],
                     min_counts = 3, min_cells = 3, min_vscore_pctl = 85, 
                     show_vscore_plot = True, num_pc = 25, pca_method = '', k_neigh=4, use_approxnn = False,
                     #exclude_corr_genes_list=[g2m_genes], exclude_corr_genes_minCorr=0.2,
                     output_spring = True, num_force_iter = 200,
                     cell_groupings = {'Sample': list(samp_id_flat[cell_ix])})
    
    np.save(main_spring_dir + s + '/cell_filter.npy', np.nonzero(cell_ix)[0])
    np.savetxt(main_spring_dir + s + '/cell_filter.txt', np.nonzero(cell_ix)[0], fmt='%i')
    
    print (time.time() - t0)


# save data excluding cell cycle-correlated genes

for s, smerge in merge_setup.items():
    t0 = time.time()
    print ('________________', s)
    
    cell_ix = np.in1d(samp_id_flat, smerge)
    
    subset_name = s + '_noCC'
    
    run_all_spring_1_6(E[cell_ix,:],
                     list(gene_list), subset_name, main_spring_dir, normalize=False, tot_counts_final = total_counts[cell_ix],
                     min_counts = 3, min_cells = 3, min_vscore_pctl = 85, 
                     show_vscore_plot = True, num_pc = 25, pca_method = '', k_neigh=4, use_approxnn = False,
                     exclude_corr_genes_list=[g2m_genes], exclude_corr_genes_minCorr=0.2,
                     output_spring = True, num_force_iter = 200,
                     cell_groupings = {'Sample': list(samp_id_flat[cell_ix])})
    
    np.save(main_spring_dir + subset_name + '/cell_filter.npy', np.nonzero(cell_ix)[0])
    np.savetxt(main_spring_dir + subset_name + '/cell_filter.txt', np.nonzero(cell_ix)[0], fmt='%i')
    
    print (time.time() - t0)

